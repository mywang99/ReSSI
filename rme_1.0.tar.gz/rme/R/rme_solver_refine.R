# Refined robust mean solver wrapper. Original author: Qian Chengde.
  rme_solver_refine <- function(X, 
                         w0 = 1, 
                         ep = 0.05,
                         lr = 1,
                         dc_rate = 0.9,
                         # up_rate = 1.05,
                         u0 = 0,
                         tol = 0.0001,
                         method = 0,
                         is_echo = F,
                         loop_max = 1000,
                         stationary_max = 2,
                         iter_power = 5000,
                         tol_pow = 1e-7,
                         Sig_0 = NULL) {
    p = ncol(X)
    if(is.null(Sig_0)){
      Sig_0 = diag(1, p, p)
    }
    Sig = matrix(0, nrow=1,ncol=1)
    ep_group = 0
    smin = 0
    is_ext = T
    start_ind = 0
    
    .Call(`_rme_rme_solver_refine_C`, t(X), Sig_0, w0, ep, lr, ep_group, smin, method, u0, is_echo, is_ext, start_ind, tol, dc_rate,loop_max, stationary_max, iter_power, tol_pow, Sig)
  }
