#include <RcppArmadillo.h>

arma::mat mat_null(1, 2);

void proj_C_v(arma::vec & w, double ep) {
    const arma::uword    n = w.n_elem;
    const double         lmax = 1.0 / ((1.0 - ep) * n);
    arma::uword          n_fea, n_front;
    const arma::vec      id_vec(n, arma::fill::ones);
    arma::vec            w_fea, dw_max, dw(n, arma::fill::zeros);
    arma::uvec           ind_sort, ind_fea;
    arma::uvec::iterator it, it_end;
    double               cons, target, tem, tem2, dw_front;
    
    w -= (arma::accu(w) - 1) * id_vec / n;
    dw.fill(0);
    for(arma::uword i = 0; i < n; ++i) {
        if(w(i) < 0) {
            dw(i) = -w(i);
            w(i)  = 0;
        }
        if(w(i) > lmax) {
            dw(i) = w(i) - lmax;
            w(i)  = lmax;
        }
    }
    
    cons = arma::sum(w);
    if(cons != 1.0){
        if(cons > 1.0) {
            ind_fea = arma::find(w > 0);
            dw_max  = w(ind_fea) + dw(ind_fea);
            target  = cons - 1.0;
        }
        else {
            ind_fea = arma::find(w < lmax);
            dw_max  = dw(ind_fea) - w(ind_fea) + lmax;
            target  = 1.0 - cons;
        }
        n_fea  = ind_fea.n_elem;
        w_fea  = w(ind_fea);
        dw_max = arma::join_vert(dw(ind_fea), dw_max);
        ind_sort = arma::sort_index(dw_max);
        it     = ind_sort.begin();
        it_end = ind_sort.end();
        tem    = 0;
        n_front = 0;
        dw_front = 0;
        for(; it != it_end; ++it) {
            tem2 = tem + n_front * (dw_max(*it) - dw_front);
            if(tem2 >= target && n_front > 0) {
                dw_front = (target - tem)/n_front + dw_front;
                break;
            }
            else {
                tem = tem2;
                dw_front = dw_max(*it);
            }
            if(*it > n_fea - 1) {
                n_front -= 1;
            }
            else {
                n_front += 1;
            }
        } // end of for
        if(cons > 1.0) {
            w(ind_fea) += dw_max.subvec(0, n_fea - 1) - dw_front;
        }
        else {
            w(ind_fea) -= dw_max.subvec(0, n_fea - 1) - dw_front;
        }
        // above, we make all the feasible points' weight diference move to dw_front; However, there will be some points that either dw_fea (i.e. dw_max.subvec(0, n_fea-1)) > dw_front or dw_max < dw_front. Hence we apply the following clipping step to correct it.
        it     = ind_fea.begin();
        it_end = ind_fea.end();
        for(; it != it_end; ++it) {
            if(w(*it) < 0)    {w(*it) = 0;}
            if(w(*it) > lmax) {w(*it) = lmax;}
        }
    }
    if(std::abs(arma::sum(w) - 1) > 1.0 / n) {
        Rcpp::Rcout << std::abs(arma::sum(w) - 1) << " warning: sum(w) != 1" << std::endl;
    }
    return;
}


void proj_unif_v(arma::vec & w, double ep, double ep_group, arma::uword smin = 1, arma::uword start_ind = 0) {
    if(ep_group < ep) {
        // Rcpp::Rcout << "Warning: ep_group should be not smaller than ep, set ep_group = ep by default" << std::endl;
        ep_group = ep;
    }
    // if(is_forward == 0) {
    //     w = arma::reverse(w);
    // }
    const arma::uword n = w.n_elem;
    if(smin > n) {
        Rcpp::Rcout << "Warning: smin is larger than n, reset smin = n." << std::endl;
        smin = n;
    }
    const double         lmax = 1.0 / ((1.0 - ep) * n);
    const double         ep_ratio = (1 - ep_group) / (1 - ep);
    const arma::vec      id_vec(n, arma::fill::ones);
    const arma::uword    num_slice = 1 + (n + start_ind % smin - 1) / smin;
    arma::uword          n_fea, n_front, slice_end, slice_start, len_slice;
    arma::vec            w_slice, dw_critical, dw_max, dw(n, arma::fill::zeros), group_constrain(num_slice);
    arma::uvec           ind_sort, ind_fea, group_fea;
    arma::uvec::iterator it, it_end;
    double               cons, target_slice, target_full, tem, tem2, dw_front;
    
    // 1. Project to sum w_j = 1
    w -= (arma::accu(w) - 1) * id_vec / n;
    // 2. clamping
    dw.fill(0);
    for(arma::uword i = 0; i < n; ++i) {
        if(w(i) < 0) {
            dw(i) = -w(i);
            w(i)  = 0;
        }
        if(w(i) > lmax) {
            dw(i) = w(i) - lmax;
            w(i)  = lmax;
        }
    } // end of clamping
    
    // 3. group constrain
    for(arma::uword k = 0; k <= num_slice - 1; ++k) {
        // compute the end and start index of the $k$-th slice
        if(k == 0) slice_start = 0;
        else slice_start = k * smin - start_ind % smin;
        if(k == num_slice - 1) slice_end = n - 1;
        else slice_end = (k+1) * smin - start_ind % smin - 1;
        
        len_slice = slice_end - slice_start + 1;
        group_constrain(k) = arma::mean(w.subvec(slice_start, slice_end)) * double(n);
        if(group_constrain(k) < ep_ratio) {
            // Rcpp::Rcout << "compare " << arma::accu(w.subvec(slice_start, slice_end)) * n << " " << len_slice << " " << k << " ";
            w_slice = w.subvec(slice_start, slice_end);
            target_slice  = (ep_ratio - group_constrain(k)) * double(len_slice) / double(n);
            ind_fea = arma::find(w_slice < lmax); n_fea  = ind_fea.n_elem;
            dw_critical  = arma::join_vert(dw(ind_fea + slice_start), dw(ind_fea + slice_start) - w_slice(ind_fea) + lmax);
            ind_sort = arma::sort_index(dw_critical);
            it      = ind_sort.begin(); it_end = ind_sort.end();
            tem     = 0; n_front = 0; dw_front = 0;
            for(; it != it_end; ++it) {
                tem2 = tem + n_front * (dw_critical(*it) - dw_front);
                if(tem2 >= target_slice && n_front > 0) {
                    dw_front = (target_slice - tem)/n_front + dw_front;
                    break;
                }
                else {
                    tem = tem2;
                    dw_front = dw_critical(*it);
                }
                if(*it > n_fea - 1) n_front -= 1;
                else                n_front += 1;
            } // end of for
            for(arma::uword i = 0; i < n_fea; ++i) {
                if(dw_front >= dw_critical(n_fea + i)) {
                    w_slice(ind_fea(i)) = lmax;
                    dw(slice_start + ind_fea(i)) = dw_critical(n_fea + i);
                }
                else if(dw_front > dw_critical(i)) {
                    w_slice(ind_fea(i)) -= (dw_critical(i) - dw_front);
                    dw(slice_start + ind_fea(i)) = dw_front;
                }
            }
            w.subvec(slice_start, slice_end) = w_slice;
            // Rcpp::Rcout << "sum of w_slice " << arma::accu(w_slice) << " " << arma::accu(w.subvec(slice_start, slice_end)) << std::endl;
        }
    } // end of group constrain
    
    // 4. check stopping criterion
    cons = arma::accu(w);
    if(std::abs(cons - 1) < 1e-4/n) {
        // Rcpp::Rcout<< "Luckeyly stop at the second procedure" << std::endl;
        // if(is_forward == 0) {
        //     w = arma::reverse(w);
        // }
        return;
    }
    
    // 5. If not, furthermore finding critical position
    if(cons < 1) {
        // Rcpp::Rcout << "small" << std::endl;
        target_full  = 1.0 - cons;
        ind_fea = arma::find(w < lmax);
        n_fea   = ind_fea.n_elem;
        dw_critical  = arma::join_vert(dw(ind_fea), dw(ind_fea) - w(ind_fea) + lmax);
    }
    else { // if(cons > 1)
        // Rcpp::Rcout << "large" << std::endl;
        target_full = cons - 1.0;
        
        // Compute the dw_max for all points; 
        dw_max = dw;
        for(arma::uword k = 0; k <= num_slice - 1; ++k) {
            // compute the end and start index of the $k$-th slice
            if(k == 0) slice_start = 0;
            else slice_start = k * smin - start_ind % smin;
            if(k == num_slice - 1) slice_end = n - 1;
            else slice_end = (k+1) * smin - start_ind % smin - 1;
            
            if(group_constrain(k) > ep_ratio) {
                // Rcpp::Rcout << "compare " << arma::accu(w.subvec(slice_start, slice_end)) * n << " " << len_slice << " " << k << std::endl;
                len_slice = slice_end - slice_start + 1;
                w_slice = w.subvec(slice_start, slice_end);
                target_slice  = (group_constrain(k) - ep_ratio) * double(len_slice) / double(n);;
                ind_fea = arma::find(w_slice > 0); n_fea  = ind_fea.n_elem;
                dw_critical  = arma::join_vert(dw(ind_fea + slice_start), dw(ind_fea + slice_start) + w_slice(ind_fea));
                ind_sort = arma::sort_index(dw_critical);
                it      = ind_sort.begin(); it_end = ind_sort.end();
                tem     = 0; n_front = 0; dw_front = 0;
                for(; it != it_end; ++it) {
                    tem2 = tem + n_front * (dw_critical(*it) - dw_front);
                    if(tem2 >= target_slice && n_front > 0) {
                        dw_front = (target_slice - tem)/n_front + dw_front;
                        break;
                    }
                    else {
                        tem = tem2;
                        dw_front = dw_critical(*it);
                    }
                    if(*it > n_fea - 1) n_front -= 1;
                    else                n_front += 1;
                } // end of for: get dw_front;
                for(arma::uword i = 0; i < n_fea; ++i) {
                    if(dw_front > dw_critical(n_fea + i)) {
                        dw_max(slice_start + ind_fea(i)) = dw_critical(n_fea + i);
                    }
                    else if(dw_front > dw_critical(i)) {
                        dw_max(slice_start + ind_fea(i)) = dw_front;
                    }
                }
            } 
        } // get dw_max
        ind_fea = arma::find(dw_max > dw);
        // Rcpp::Rcout << arma::max(ind_fea) << std::endl;
        n_fea   = ind_fea.n_elem;
        dw_critical =  arma::join_vert(dw(ind_fea), dw_max(ind_fea));
    } // end if: get ind_fea n_fea and dw_critical for the global sequence;
    ind_sort = arma::sort_index(dw_critical);
    it      = ind_sort.begin(); it_end = ind_sort.end();
    tem     = 0; n_front = 0; dw_front = 0;
    for(; it != it_end; ++it) {
        tem2 = tem + n_front * (dw_critical(*it) - dw_front);
        if(tem2 >= target_full && n_front > 0) {
            dw_front = (target_full - tem)/n_front + dw_front;
            break;
        }
        else {
            tem = tem2;
            dw_front = dw_critical(*it);
        }
        if(*it > n_fea - 1) {
            n_front -= 1;
        }
        else {
            n_front += 1;
        }
    } // end of for: get dw_front, the critical position;
    
    // 6. compute the optimal weight
    if(cons < 1) {
        for(arma::uword i = 0; i < n_fea; ++i) {
            if(dw_front > dw_critical(n_fea + i)) {
                w(ind_fea(i)) = lmax;
            }
            else if(dw_front > dw_critical(i)) {
                w(ind_fea(i)) += dw_front - dw_critical(i);
            }
        }
    }
    else { // cons > 1
        for(arma::uword i = 0; i < n_fea; ++i) {
            if(dw_front > dw_critical(n_fea + i)) {
                w(ind_fea(i)) -= dw_critical(n_fea + i) - dw_critical(i);
            }
            else if(dw_front > dw_critical(i)) {
                w(ind_fea(i)) -= dw_front - dw_critical(i);
            }
        }
    } // end of if: get the optimal weight
    
    if(std::abs(arma::sum(w) - 1) > 1e-4 / n) {
        Rcpp::Rcout << std::abs(arma::sum(w) - 1) << " warning: sum(w) != 1" << std::endl;
    }
    // if(is_forward == 0) {
    //     w = arma::reverse(w);
    // }
    return;
}

double weight_loss(const arma::vec & ele_loss, 
                   const double & ep,
                   double ep_group,
                   arma::uword smin = 1,
                   const arma::uword start_ind = 0) {
    if(ep_group < ep && ep_group > 0) {
        Rcpp::Rcout << "Warning: ep_group should be not smaller than ep, set ep_group = ep by default" << std::endl;
        ep_group = ep;
    }
    const arma::uword n = ele_loss.n_elem;
    arma::uword num_weight_zero = std::floor(n * ep);
    arma::uword end_slice, start_slice;
    arma::uvec idx_sort_loss;
    arma::vec loss, loss_copy, slice_loss, weight_outlier;
    double sum_w, loss_out, low_cri, up_cri, gap_w;
    auto m = loss.begin();
    bool is_skip = true;
    
    if(smin > n) {
        Rcpp::Rcout << "Warning: smin is larger than n, reset smin = n." << std::endl;
        smin = n;
    }
    
    loss = ele_loss;
    m = loss.begin() + n - num_weight_zero;
    std::nth_element(loss.begin(), m, loss.end());
    if(ep_group <= 0 || smin <= 1) {
        // no groups
        return arma::accu(loss.head(n - num_weight_zero)) - (n * ep - num_weight_zero) * *m;
    }
    const arma::uword num_slice = 1 + (n + start_ind % smin - 1) / smin;
    for(arma::uword k = 0; k <= num_slice - 1; ++k) {
        if(k == 0) start_slice = 0;
        else start_slice = k * smin - start_ind % smin;
        if(k == num_slice - 1) end_slice = n - 1;
        else end_slice = (k+1) * smin - start_ind % smin - 1;
        idx_sort_loss = arma::find(ele_loss.subvec(start_slice, end_slice) >= *m);
        if(idx_sort_loss.n_elem > (end_slice - start_slice + 1) * ep_group) {
            is_skip = false;
            break;
        }
    }
    if(is_skip) {
        return arma::accu(loss.head(n - num_weight_zero)) - (n * ep - num_weight_zero) * *m; 
    }
    
    loss.set_size(0);
    weight_outlier.set_size(0);
    for(arma::uword k = 0; k <= num_slice - 1; ++k) {
        if(k == 0) start_slice = 0;
        else start_slice = k * smin - start_ind % smin;
        if(k == num_slice - 1) end_slice = n - 1;
        else end_slice = (k+1) * smin - start_ind % smin - 1;
        slice_loss = ele_loss.subvec(start_slice, end_slice);
        num_weight_zero = std::floor(slice_loss.n_elem * ep_group);
        m = slice_loss.begin() + slice_loss.n_elem - 1 - num_weight_zero;
        std::nth_element(slice_loss.begin(), m, slice_loss.end());
        loss.resize(loss.n_elem + num_weight_zero + 1);
        loss.tail(num_weight_zero + 1) = slice_loss.tail(num_weight_zero + 1);
        weight_outlier.resize(loss.n_elem);
        weight_outlier.tail(num_weight_zero + 1).ones();
        weight_outlier(weight_outlier.n_elem - 1 - num_weight_zero) = slice_loss.n_elem * ep_group - num_weight_zero;
    }
    loss_copy = loss;
    m = loss_copy.begin() + loss_copy.n_elem - arma::uword(std::ceil(n * ep));
    std::nth_element(loss_copy.begin(), m, loss_copy.end());
    up_cri = *m;
    idx_sort_loss = arma::find(loss > up_cri);
    sum_w = arma::accu(weight_outlier(idx_sort_loss));
    loss_out = arma::accu(weight_outlier(idx_sort_loss) % loss(idx_sort_loss));
    if(arma::accu(weight_outlier(arma::find(loss >= up_cri))) >= n * ep) {
        return arma::accu(ele_loss) - loss_out - up_cri * (n * ep - sum_w);
    }
    const arma::uword num_cri_max = std::min(arma::uword(std::ceil(n * ep) + std::floor(n * ep / (smin * ep_group)) + 2), loss.n_elem);
    m = loss_copy.begin() + loss_copy.n_elem - num_cri_max;
    std::nth_element(loss_copy.begin(), m, loss_copy.end());
    low_cri = *m;
    idx_sort_loss = arma::find(loss >= low_cri && loss <= up_cri);
    weight_outlier = weight_outlier(idx_sort_loss);
    loss = loss(idx_sort_loss);
    idx_sort_loss = arma::sort_index(loss, "descend");
    gap_w = n * ep - sum_w;
    sum_w = 0;
    for(arma::uvec::iterator it = idx_sort_loss.begin(); it !=idx_sort_loss.end(); ++it) {
        sum_w += weight_outlier(*it);
        if(sum_w >= gap_w) {
            return arma::accu(ele_loss) - loss_out - loss(*it) * (weight_outlier(*it) - sum_w + gap_w);
        }
        loss_out += loss(*it) * weight_outlier(*it);
    }
    Rcpp::Rcerr << "gap_w is not zero" << std::endl;
    return arma::accu(ele_loss) - loss_out;
}
