#ifndef _UTILS_H
#define _UTILS_H

#include <RcppArmadillo.h>
extern arma::mat mat_null;

// via the depends attribute we tell Rcpp to create hooks for
// RcppArmadillo so that the build process will know what to do
//
// [[Rcpp::depends(RcppArmadillo)]]

arma::field<arma::vec> rme_solver_refine_C(
                const arma::mat &   X,
                const arma::mat &   Sig0,
                const arma::vec &   w0, 
                const double &      ep,
                double              lr,
                const double &      ep_group,
                const arma::uword & smin,
                const arma::uword & method,
                const arma::vec &   u0,
                const bool &        is_echo,
                const bool &        is_ext,
                const arma::uword & start_ind,
                const double &      tol,
                const double &      dc_rate,
                const arma::uword & loop_max,
                const arma::uword & stationary_max,
                const arma::uword & iter_power,
                const double &      tol_pow,
                arma::mat           Sig);

arma::field<arma::vec> geom_solver_C(
        const arma::mat &   X, 
        const bool &        is_echo,
        const double &      tol);

double weight_loss(const arma::vec & ele_loss, 
                   const double &    ep,
                   double            ep_group,
                   arma::uword       smin,
                   const arma::uword start_ind);

void proj_C_v(arma::vec & w, double ep);

void proj_unif_v(arma::vec & w, 
                 double ep, 
                 double ep_group, 
                 arma::uword smin = 1, 
                 arma::uword start_ind = 0);



#endif
