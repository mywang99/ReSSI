/**
 * @file rme_solver_C.cpp
 * @author Qian Chengde
 * @email qianchd at gmail dot com
 * @version 1.0
 * @date 2021-11-21
 * @brief robust mean estimation via first order method
 * @details 
 * @see some url
 * @note some remark
 * @todo Boosting the F-norm method
 */


// we only include RcppArmadillo.h which pulls Rcpp.h in for us

#include <RcppArmadillo.h>
#include <iostream>
#include "utils.h"

// [[Rcpp::export]]
arma::field<arma::vec> rme_solver_refine_C(
    const arma::mat &   X, 
    const arma::mat &   Sig_0,
    const arma::vec &   w0, 
    const double &      ep,
    double              lr,
    const double &      ep_group,
    const arma::uword & smin,
    const arma::uword & method,
    const arma::vec &   u0,
    const bool &        is_echo,
    const bool &        is_ext,
    const arma::uword & start_ind,
    const double &      tol,
    const double &      dc_rate,
    const arma::uword & loop_max,
    const arma::uword & stationary_max,
    const arma::uword & iter_power,
    const double &      tol_pow,
    arma::mat           Sig)
{
  arma::uword   n = X.n_cols, d = X.n_rows;
  arma::uword   loop; // break the while loop
  const double  lmax = 1.0 / (n * (1.0 - ep));
  arma::mat   Sig_old(d, d, arma::fill::zeros);
  arma::vec   u(d, arma::fill::value(1.0/std::sqrt(d))), u_tem, u_old, u_pow_old;
  double lambda = 0, lambda_old = 0;
  const arma::vec  id_vec(d, arma::fill::ones);
  arma::vec   w(n, arma::fill::value(lmax)), w_old(n, arma::fill::zeros), dw(n, arma::fill::zeros);
  if(n * ep >= 1){
    // w.subvec(0, arma::uword(n * ep - 1)) = arma::zeros<arma::vec>(arma::uword(n * ep)); // TODO: initial estimator of the outliers
    w.fill(1.0/n);
  }
  else{
    w.fill(1.0/n);
  }
  arma::vec   dw_max, mu_old(d, arma::fill::zeros), w_fea, dw_fea, grad(n);
  arma::uvec  ind_fea, ind_sort, ind_min, ind_tem, ind_diff;
  arma::uword stationary_counter = 0;
  double obj = DBL_MAX, obj_old = DBL_MAX;
  double sign_obj = 0;
  
  arma::field<arma::vec> res(5);
  
  
  if(u0.n_elem == d && d != 1) {
    u = u0;
  }
  if(w0.n_elem == n && is_ext == true) {
    w = w0;
  }
  
  arma::vec mu = X * w;
  
  if(w0.n_elem != n || is_ext == false || Sig(0,0) == -1 || Sig.n_cols != d || Sig.n_rows != d || d == 1) {
    // Xw = X.each_row() % arma::sqrt(w.t());
    Sig = X * arma::diagmat(w) * X.t() - mu * mu.t() - Sig_0;
    // Rcpp::Rcout << "Sig matrix content:\n" << Sig << std::endl;
    // 
    // // 打印维度信息
    // Rcpp::Rcout << "Sig dimensions: " << Sig.n_rows << " x " << Sig.n_cols << std::endl;
    // 
    // // 打印类型信息（有限信息）
    // Rcpp::Rcout << "Template type: " << typeid(Sig).name() << std::endl;
    // 
    // Rcpp::Rcout << "Initial Sig done!" << std::endl;
  }
  
  loop = 0;
  while(lr > tol && stationary_counter < stationary_max){
    // Rcpp::Rcout << "Iter " << loop << ": ";
    if(loop > loop_max){
      // if(is_echo == 1)
      Rcpp::Rcout << "while breaks" << std::endl;
      break;
    }
    else
      ++loop;
    
    // Rcpp::Rcout << "Use method " << method << std::endl;
    /// 1. Gradient step
    if(method == 1){  
      // nuclear norm
      obj = arma::trace(Sig);
      if(obj >= obj_old || std::isnan(obj)){
        lr *= dc_rate;
        if(is_echo == 1)
          Rcpp::Rcout << obj << " " << obj_old << " learning rate decays to " << lr << std::endl;
        obj = obj_old;
        w   = w_old;
        mu  = mu_old;
        Sig = Sig_old;
        stationary_counter = 0;
      }
      else{
        if((obj_old - obj) < 0.01 * arma::norm(w_old - w)){ //|| (obj_old - obj) < 0.001 * (obj_old + obj)){
          ++stationary_counter;
        }
        lr *= 1.2;
        if(is_echo == 1)
          Rcpp::Rcout << obj << " " << obj_old << " learning rate holds" << lr << std::endl;
        grad = arma::sum(arma::square(X.t()), 1) - 2.0 * X.t() * mu;
      }
    }
    else if(method == 2) {
      // F norm
      obj = norm(Sig, "fro");
      
      if(obj >= obj_old || std::isnan(obj)){
        lr *= dc_rate;
        if(is_echo == 1)
          Rcpp::Rcout << obj << " " << obj_old << " learning rate decays to " << lr << std::endl;
        obj = obj_old;
        w   = w_old;
        mu  = mu_old;
        Sig = Sig_old;
        stationary_counter = 0;
      }
      else{
        // Rcpp::Rcout<<  (obj_old - obj) / (std::sqrt(n) * arma::norm(w_old - w)) << std::endl;
        if((obj_old - obj) < 1e-4 * std::sqrt(n) * arma::norm(w_old - w)\
             || (obj_old - obj) < 0.001 * (obj_old + obj)){
          ++stationary_counter;
        }
        lr *= 1.2;
        if(is_echo == 1)
          Rcpp::Rcout << obj << " " << obj_old << " learning rate holds" << lr << std::endl;
        // for(arma::uword i = 0; i < n; ++i) {
        //     grad(i) = arma::as_scalar(X.col(i).t() * Sig * (X.col(i) - 2 * mu) / (obj * n));
        // }
        //std::transform(X.begin_col(), X.end_col(), grad.begin(),
        //               [=](arma::vec x) -> double { return arma::as_scalar(x.t() * Sig * (x - 2 * mu)); });
        //grad /= obj*n;
        //grad  = (id_vec.t() * ((Sig * X) % X) - 2.0 * mu.t() * Sig * X).as_col() / (obj * n);
        grad  = (arma::sum((Sig * X) % X, 0) - 2.0 * mu.t() * Sig * X).as_col() / (obj * n);
      }
    }
    else{
      // operator norm
      /// @brief find the first eigenvector via power method;
      
      // for(arma::uword i = 0; i < iter_power; ++i) {
      //   u_pow_old = u;
      //   lambda_old = lambda;
      //   u = (Sig * u - 0.333 * lambda * u);
      //   // Rcpp::Rcout << "norm(u)" << arma::norm(u) << std::endl;
      //   lambda = (arma::norm(u) / arma::norm(u_pow_old) + 0.333 * lambda);
      //   // Rcpp::Rcout << "norm(u_pow_old)" << arma::norm(u_pow_old) << std::endl;
      //   // Rcpp::Rcout << "lambda :\n" << lambda << std::endl;
      //   u = u / arma::max(arma::abs(u));
      //   if(std::abs((lambda - lambda_old)/lambda) < tol_pow) break;
      // }
      for(arma::uword i = 0; i < iter_power; ++i) {
        u_pow_old = u;
        lambda_old = lambda;
        u = Sig * u;
        lambda = arma::norm(u) / arma::norm(u_pow_old);
        // Rcpp::Rcout << "norm(u)" << arma::norm(u) << std::endl;
        // Rcpp::Rcout << "lambda :\n" << lambda << std::endl;
        // Rcpp::Rcout << "norm(u_pow_old)" << arma::norm(u_pow_old) << std::endl;
        u = u / arma::max(arma::abs(u));
        if(std::abs((lambda - lambda_old)/lambda) < tol_pow) break;
      }
      
      u   = arma::normalise(u);
      sign_obj = arma::as_scalar(u.t() * Sig * u);
      obj = std::abs(sign_obj);
      
      if(obj - obj_old > 1e-8 || std::isnan(obj)){
        lr *= dc_rate;
        if(is_echo == 1)
          Rcpp::Rcout << sign_obj << " " << obj << " " << obj_old << " learning rate decays to " << lr << std::endl;
        obj = obj_old;
        w   = w_old;
        u   = u_old;
        mu  = mu_old;
        Sig = Sig_old;
        stationary_counter = 0;
      }
      else{
        // Rcpp::Rcout << (obj_old - obj) << " " << 0.1 * std::sqrt(n / ep) * arma::norm(w_old - w) << std::endl;
        if((obj_old - obj) / 0.0011 <=  std::sqrt(n / ep) * arma::norm(w_old - w)){ //|| (obj_old - obj) < 0.001 * (obj_old + obj)){
          ++stationary_counter;
          // Rcpp::Rcout << "stat count: " << stationary_counter << std::endl; 
        }
        lr = std::min(lr * 1.05, 2.0);
        if(is_echo == 1)
          Rcpp::Rcout << sign_obj << " " << obj << " " << obj_old << " learning rate holds " << lr << std::endl;
        u_old = u;
        if(sign_obj >= 0) {
          grad  = (arma::square(X.t() * u) - (X.t() * u) * (2.0 * mu.t() * u)) / n;
        }
        else {
          grad  = -(arma::square(X.t() * u) - (X.t() * u) * (2.0 * mu.t() * u)) / n;
        }
      }
    } // end of the method selector
    
    //Rcpp::Rcout << "while loop " << loop << " "<< obj << " " << obj_old  << std::endl;
    
    obj_old = obj;
    w_old   = w;
    mu_old  = mu;
    Sig_old = Sig;
    w      -= lr * grad;
    /// Projection to $\Delta_{n, \epsilon}$
    if(ep_group <= 0 || smin <= 1)
      proj_C_v(w, ep);
    else
      proj_unif_v(w, ep, ep_group, smin, start_ind);
    
    /// 0. compute mu and Sig
    ind_diff = arma::find(w - w_old != 0);
    //Rcpp::Rcout << "number of diff " << ind_diff.n_elem << std::endl; 
    if(ind_diff.n_elem < n / 3) {
      if (ind_diff.n_elem == 0) {
        stationary_counter++;
        continue;
      }
      // Rcpp::Rcout << "number of diff " << ind_diff.n_elem << std::endl;
      
      // Xw = X.cols(ind_diff);
      mu += X.cols(ind_diff) * (w(ind_diff) - w_old(ind_diff));
      Sig += X.cols(ind_diff) * arma::diagmat(w(ind_diff) - w_old(ind_diff)) * X.cols(ind_diff).t() - mu * mu.t() + mu_old * mu_old.t();
      //Xw.each_row() %= (w(ind_diff).t() - w_old(ind_diff).t());
      //Sig += X.cols(ind_diff) * Xw.t() - mu * mu.t() + mu_old * mu_old.t();
    }
    else {
      mu = X * w;
      Sig = X * arma::diagmat(w) * X.t() - mu * mu.t() - Sig_0;
      //Xw = X.each_row() % arma::sqrt(w.t());
      //Sig = Xw * Xw.t() - mu * mu.t();
    }
  } // end of while
  res(0) = mu;
  res(1) = w;
  res(2) = obj;
  res(3) = u;
  res(4) = Sig.as_col();
  return res;
}
